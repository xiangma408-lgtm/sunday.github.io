import React from 'react';

interface NewtonAvatarProps {
  imageUrl: string;
  isSpeaking: boolean;
}

const NewtonAvatar: React.FC<NewtonAvatarProps> = ({ imageUrl, isSpeaking }) => {
  return (
    <div className="relative w-48 h-48 md:w-64 md:h-64 rounded-full border-4 border-yellow-600/50 shadow-2xl overflow-hidden bg-stone-800">
      <img 
        src={imageUrl} 
        alt="Isaac Newton" 
        className="w-full h-full object-cover transition-transform duration-1000 hover:scale-105"
      />
      
      {/* Speaking Animation Overlay */}
      {isSpeaking && (
        <div className="absolute inset-0 flex items-center justify-center">
           <div className="absolute bottom-0 w-full h-1/3 bg-gradient-to-t from-black/60 to-transparent"></div>
           {/* Simple visualizer simulation */}
           <div className="absolute bottom-4 flex gap-1 h-8 items-end">
              <div className="w-1 bg-yellow-400/80 animate-[bounce_0.5s_infinite]"></div>
              <div className="w-1 bg-yellow-400/80 animate-[bounce_0.7s_infinite]"></div>
              <div className="w-1 bg-yellow-400/80 animate-[bounce_0.4s_infinite]"></div>
              <div className="w-1 bg-yellow-400/80 animate-[bounce_0.6s_infinite]"></div>
              <div className="w-1 bg-yellow-400/80 animate-[bounce_0.5s_infinite]"></div>
           </div>
        </div>
      )}
    </div>
  );
};

export default NewtonAvatar;