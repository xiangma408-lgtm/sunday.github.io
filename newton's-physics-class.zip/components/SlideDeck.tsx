import React, { useEffect, useState } from 'react';
import { Slide } from '../types';
import katex from 'katex';

interface SlideDeckProps {
  slide: Slide;
  totalSlides: number;
  isEditing: boolean;
  onUpdate: (updatedSlide: Slide) => void;
  audioProgress: number; // 0 to 1
}

const SlideDeck: React.FC<SlideDeckProps> = ({ slide, totalSlides, isEditing, onUpdate, audioProgress }) => {
  // Local state for editing
  const [editTitle, setEditTitle] = useState(slide.title);
  const [editContent, setEditContent] = useState(slide.content.join('\n'));
  const [editSpeakerNotes, setEditSpeakerNotes] = useState(slide.speakerNotes);

  // Sync local state when slide changes
  useEffect(() => {
    setEditTitle(slide.title);
    setEditContent(slide.content.join('\n'));
    setEditSpeakerNotes(slide.speakerNotes);
  }, [slide.id, slide.title, slide.content, slide.speakerNotes]);

  // Calculate which bullet point should be highlighted based on audio progress
  const activeIndex = Math.floor(audioProgress * slide.content.length);

  const handleSave = () => {
    onUpdate({
        ...slide,
        title: editTitle,
        content: editContent.split('\n').filter(line => line.trim() !== ''),
        speakerNotes: editSpeakerNotes
    });
  };

  // Helper to render text that might contain $...$ inline latex
  const renderTextWithLatex = (text: string, isActive: boolean) => {
    // Split by $...$ delimiters. 
    const parts = text.split(/(\$[^$]+\$)/g);
    
    return parts.map((part, index) => {
        if (part.startsWith('$') && part.endsWith('$')) {
            const tex = part.slice(1, -1);
            try {
                // Ensure consistent display mode even for inline for better visibility
                const html = katex.renderToString(tex, {
                    throwOnError: false,
                    displayMode: false,
                    output: 'html' 
                });
                return <span key={index} dangerouslySetInnerHTML={{ __html: html }} className="mx-1 inline-block align-middle" />;
            } catch (e) {
                console.warn("Inline latex error", e);
                return <span key={index}>{part}</span>;
            }
        }
        return <span key={index}>{part}</span>;
    });
  };

  if (isEditing) {
      return (
        <div className="w-full h-full flex flex-col p-8 text-white relative overflow-hidden bg-black/60 backdrop-blur-md z-40">
            <h3 className="text-yellow-400 font-bold mb-4">编辑幻灯片</h3>
            
            <div className="flex flex-col gap-4 flex-grow overflow-y-auto">
                <div>
                    <label className="block text-sm text-stone-300 mb-1">标题</label>
                    <input 
                        type="text" 
                        value={editTitle}
                        onChange={(e) => setEditTitle(e.target.value)}
                        className="w-full bg-stone-800 border border-stone-600 rounded p-2 text-white"
                    />
                </div>

                <div>
                    <label className="block text-sm text-stone-300 mb-1">内容 (每行一点，支持 $E=mc^2$)</label>
                    <textarea 
                        value={editContent}
                        onChange={(e) => setEditContent(e.target.value)}
                        className="w-full h-32 bg-stone-800 border border-stone-600 rounded p-2 text-white font-mono text-sm"
                    />
                </div>

                <div>
                    <label className="block text-sm text-stone-300 mb-1">讲解字幕 (支持 $F=ma$)</label>
                    <textarea 
                        value={editSpeakerNotes}
                        onChange={(e) => setEditSpeakerNotes(e.target.value)}
                        className="w-full h-24 bg-stone-800 border border-stone-600 rounded p-2 text-white font-mono text-sm"
                    />
                    <p className="text-xs text-stone-400 mt-1">注：修改字幕文本不会重新生成语音。</p>
                </div>
            </div>

            <button 
                onClick={handleSave}
                className="mt-4 bg-green-600 hover:bg-green-700 text-white py-2 rounded font-bold transition-colors"
            >
                保存更改
            </button>
        </div>
      );
  }

  return (
    <div className="w-full h-full flex flex-col p-6 md:p-8 text-white relative overflow-hidden">
        {/* Chalk dust effect overlay */}
        <div className="absolute inset-0 pointer-events-none opacity-20 bg-[url('https://www.transparenttextures.com/patterns/black-scales.png')]"></div>

        <div className="relative z-10 flex flex-col h-full">
            {/* Header */}
            <div className="border-b-2 border-white/30 pb-3 mb-4 flex justify-between items-end shrink-0">
                <h2 className="text-3xl md:text-4xl font-serif font-bold text-yellow-100 tracking-wide leading-tight drop-shadow-md">
                    {renderTextWithLatex(slide.title, false)}
                </h2>
                <span className="text-xl font-mono text-white/50 ml-4 font-bold">
                    {slide.id} / {totalSlides}
                </span>
            </div>

            {/* Main Content Area - Split Layout (50/50 approx) */}
            <div className="flex-grow flex flex-row gap-6 overflow-hidden min-h-0">
                {/* Text Content - Adjusted font size to avoid scrolling */}
                <div className="w-1/2 flex flex-col pr-2">
                    <ul className="list-disc pl-6 space-y-4 text-xl md:text-2xl leading-relaxed font-serif">
                        {slide.content.map((point, index) => {
                            const isActive = index === activeIndex;
                            return (
                                <li 
                                    key={index} 
                                    className={`pl-1 transition-all duration-500 ease-in-out ${isActive ? 'text-red-400 font-medium drop-shadow-md' : 'text-white/80'}`}
                                >
                                    {renderTextWithLatex(point, isActive)}
                                </li>
                            );
                        })}
                    </ul>
                </div>

                {/* Generated Diagram (Visual) - Always rendered now */}
                <div className="w-1/2 flex flex-col items-center justify-center h-full pb-4">
                    {slide.visualUrl ? (
                        <div className="relative p-2 bg-white/5 border-2 border-white/10 rounded shadow-2xl transform hover:scale-105 transition-transform duration-500 backdrop-blur-sm max-h-full max-w-full flex items-center justify-center">
                             {/* Pin effect */}
                             <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-red-800 shadow-md border border-red-900 z-10"></div>
                             
                             <img 
                                src={slide.visualUrl} 
                                alt="Physics Diagram" 
                                className="max-h-[50vh] w-auto object-contain rounded opacity-90 invert" 
                                style={{ filter: 'invert(1) grayscale(1) contrast(1.5)' }}
                             />
                        </div>
                    ) : (
                        <div className="text-white/30 border-2 border-dashed border-white/20 p-8 rounded text-center">
                            等待绘图...
                        </div>
                    )}
                </div>
            </div>
        </div>
    </div>
  );
};

export default SlideDeck;