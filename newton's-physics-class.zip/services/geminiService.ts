import { GoogleGenAI, Modality, Type } from "@google/genai";
import { Slide, SolutionData } from "../types";

// Helper to validate API Key
const getApiKey = () => {
  const key = process.env.API_KEY;
  if (!key) {
    throw new Error("API Key not found in environment variables.");
  }
  return key;
};

// --- Audio Helper Functions ---

// Convert Base64 string to Uint8Array
function base64ToUint8Array(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

// Write string to DataView
function writeString(view: DataView, offset: number, string: string) {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}

// Add WAV header to raw PCM data
function addWavHeader(pcmData: Uint8Array, sampleRate: number, numChannels: number): ArrayBuffer {
  const headerLength = 44;
  const dataLength = pcmData.length;
  const buffer = new ArrayBuffer(headerLength + dataLength);
  const view = new DataView(buffer);

  // RIFF identifier
  writeString(view, 0, 'RIFF');
  // file length
  view.setUint32(4, 36 + dataLength, true);
  // RIFF type
  writeString(view, 8, 'WAVE');
  // format chunk identifier
  writeString(view, 12, 'fmt ');
  // format chunk length
  view.setUint32(16, 16, true);
  // sample format (raw)
  view.setUint16(20, 1, true);
  // channel count
  view.setUint16(22, numChannels, true);
  // sample rate
  view.setUint32(24, sampleRate, true);
  // byte rate (sampleRate * blockAlign)
  view.setUint32(28, sampleRate * numChannels * 2, true);
  // block align (channel count * bytes per sample)
  view.setUint16(32, numChannels * 2, true);
  // bits per sample
  view.setUint16(34, 16, true);
  // data chunk identifier
  writeString(view, 36, 'data');
  // data chunk length
  view.setUint32(40, dataLength, true);

  // write PCM data
  const pcmBytes = new Uint8Array(buffer, headerLength);
  pcmBytes.set(pcmData);

  return buffer;
}

// ------------------------------

// 1. Analyze the physics image and generate the slide deck content
export const analyzePhysicsImage = async (base64Image: string, mimeType: string): Promise<SolutionData> => {
  const ai = new GoogleGenAI({ apiKey: getApiKey() });
  
  const prompt = `
    你现在是伟大的物理学家艾萨克·牛顿爵士。
    请分析提供的物理题目图片。
    1. 识别涉及的物理原理。
    2. 一步步解决问题。
    3. 将输出格式化为幻灯片 JSON。

    **关键指令（必须严格遵守）：**

    1. **Latex 符号全覆盖（PPT和讲解都要用）**：
       - 文中出现的**所有**物理量符号（如 $m, v, a, F$）、数字与单位组合（如 $5kg, 10m/s^2$）、数学运算符，**必须**包裹在单美元符号 $ 中。
       - **错误示例**：物体质量为m，速度是5m/s。
       - **正确示例**：物体质量为 $m$，速度是 $5m/s$。
       - 重点结果（如答案）请使用颜色高亮：$\\textcolor{orange}{F = 20N}$。

    2. **大白话讲解 (Speaker Notes)**：
       - "speakerNotes" 必须使用**极度通俗、口语化**的中文。
       - **讲解中的公式也要用Latex格式**（例如：不要说“F等于ma”，要写“根据 $F=ma$”）。
       - 解释物理意义（如“力越大，加速就越猛”）。

    3. **每一页都要有配图 (Visual Prompt)**：
       - **每一张**幻灯片必须包含 "visualPrompt"。
       - 即使是纯公式推导页，也要描述一个辅助理解的几何示意图或受力分析图。
       - 示例："A minimalist chalkboard diagram showing the free body diagram of the block with force vectors $mg$ and $N$."

    4. **内容精简 (Content)**：
       - 每张幻灯片的 content 数组最多包含 4-5 行。
       - 文字要精炼，确保屏幕放得下，不要长篇大论。

    JSON 结构：
    {
      "title": "问题的简短标题",
      "slides": [
        {
          "id": 1,
          "title": "幻灯片标题",
          "content": ["要点 1 (含 $公式$)", "要点 2"],
          "visualPrompt": "Detailed visual description of a diagram for THIS specific slide step (English)",
          "speakerNotes": "通俗易懂的中文口语讲解，公式用 $...$ 包裹"
        }
      ]
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          { inlineData: { mimeType, data: base64Image } },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            slides: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.INTEGER },
                  title: { type: Type.STRING },
                  content: { type: Type.ARRAY, items: { type: Type.STRING } },
                  visualPrompt: { type: Type.STRING }, // Made required conceptually via prompt
                  speakerNotes: { type: Type.STRING }
                },
                required: ["id", "title", "content", "speakerNotes", "visualPrompt"]
              }
            }
          },
          required: ["title", "slides"]
        }
      }
    });

    if (response.text) {
      let jsonStr = response.text.trim();
      if (jsonStr.startsWith("```json")) {
        jsonStr = jsonStr.replace(/^```json\n?/, "").replace(/\n?```$/, "");
      } else if (jsonStr.startsWith("```")) {
        jsonStr = jsonStr.replace(/^```\n?/, "").replace(/\n?```$/, "");
      }
      return JSON.parse(jsonStr) as SolutionData;
    }
    throw new Error("No text returned from analysis.");
  } catch (error) {
    console.error("Error analyzing image:", error);
    throw error;
  }
};

// 2. Generate a Diagram (New function)
export const generateDiagram = async (prompt: string): Promise<string> => {
    const ai = new GoogleGenAI({ apiKey: getApiKey() });
    
    // Enhance prompt to ensure matching geometry
    const stylePrompt = `
      Create a precise educational physics diagram on a blackboard style.
      White chalk lines on dark background. High contrast.
      
      CRITICAL: strict geometric accuracy based on this description: ${prompt}
      
      Style: Minimalist, schematic, clear arrows for vectors. No text labels if possible.
    `;
  
    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-image", 
        contents: {
          parts: [{ text: stylePrompt }]
        }
      });
  
      for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
        }
      }
      return ""; // Return empty if failed, don't break app
    } catch (error) {
      console.warn("Error generating diagram:", error);
      return "";
    }
};

// 3. Generate an image of Isaac Newton
export const generateNewtonAvatar = async (): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: getApiKey() });
  
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-image", 
      contents: {
        parts: [{ 
          text: "A classic oil painting portrait of Sir Isaac Newton, dark background, looking at camera, high quality, photorealistic." 
        }]
      },
      config: {}
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    throw new Error("No image generated.");
  } catch (error) {
    console.error("Error generating avatar:", error);
    return "https://upload.wikimedia.org/wikipedia/commons/3/39/GodfreyKneller-IsaacNewton-1689.jpg";
  }
};

// 4. Generate Speech for a specific text
export const generateSpeech = async (text: string): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: getApiKey() });
  
  try {
    // Remove LaTeX delimiters for TTS readability, or keep them if TTS handles them well.
    // Generally, clean text is better for TTS, but for now we pass raw.
    // Better practice: Strip $ signs for the audio generation prompt.
    const cleanText = text.replace(/\$/g, "");

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: {
        parts: [{ text: cleanText }]
      },
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: "Fenrir" } 
          }
        }
      }
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (base64Audio) {
      const pcmBytes = base64ToUint8Array(base64Audio);
      const wavBuffer = addWavHeader(pcmBytes, 24000, 1);
      const blob = new Blob([wavBuffer], { type: 'audio/wav' });
      return URL.createObjectURL(blob);
    }
    throw new Error("No audio generated.");
  } catch (error) {
    console.error("Error generating speech:", error);
    throw error;
  }
};